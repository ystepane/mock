import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/TableComponent.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=239115ef"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/karav/OneDrive/Documents/CS32/mock-bkaravan-ystepane/src/components/TableComponent.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
const TableComponent = ({
  data
}) => {
  return /* @__PURE__ */ jsxDEV("table", { className: "centered-table", children: /* @__PURE__ */ jsxDEV("tbody", { children: data.map((row, rowIndex) => /* @__PURE__ */ jsxDEV("tr", { children: row.map((cell, cellIndex) => /* @__PURE__ */ jsxDEV("td", { children: cell }, cellIndex, false, {
    fileName: "C:/Users/karav/OneDrive/Documents/CS32/mock-bkaravan-ystepane/src/components/TableComponent.tsx",
    lineNumber: 11,
    columnNumber: 43
  }, this)) }, rowIndex, false, {
    fileName: "C:/Users/karav/OneDrive/Documents/CS32/mock-bkaravan-ystepane/src/components/TableComponent.tsx",
    lineNumber: 10,
    columnNumber: 38
  }, this)) }, void 0, false, {
    fileName: "C:/Users/karav/OneDrive/Documents/CS32/mock-bkaravan-ystepane/src/components/TableComponent.tsx",
    lineNumber: 9,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/karav/OneDrive/Documents/CS32/mock-bkaravan-ystepane/src/components/TableComponent.tsx",
    lineNumber: 8,
    columnNumber: 10
  }, this);
};
_c = TableComponent;
export default TableComponent;
var _c;
$RefreshReg$(_c, "TableComponent");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/karav/OneDrive/Documents/CS32/mock-bkaravan-ystepane/src/components/TableComponent.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBYWM7QUFiZCxPQUFPQSxvQkFBa0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTXpCLE1BQU1DLGlCQUFrQ0EsQ0FBQztBQUFBLEVBQUVDO0FBQUssTUFBTTtBQUNwRCxTQUNFLHVCQUFDLFdBQU0sV0FBVSxrQkFDZixpQ0FBQyxXQUNFQSxlQUFLQyxJQUFJLENBQUNDLEtBQUtDLGFBQ2QsdUJBQUMsUUFDRUQsY0FBSUQsSUFBSSxDQUFDRyxNQUFNQyxjQUNkLHVCQUFDLFFBQW9CRCxrQkFBWkMsV0FBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQTBCLENBQzNCLEtBSE1GLFVBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUlBLENBQ0QsS0FQSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBUUEsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBVUE7QUFFSjtBQUFFRyxLQWRJUDtBQWdCTixlQUFlQTtBQUFlLElBQUFPO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsIlRhYmxlQ29tcG9uZW50IiwiZGF0YSIsIm1hcCIsInJvdyIsInJvd0luZGV4IiwiY2VsbCIsImNlbGxJbmRleCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiVGFibGVDb21wb25lbnQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcclxuXHJcbmludGVyZmFjZSBQcm9wcyB7XHJcbiAgZGF0YTogc3RyaW5nW11bXTtcclxufVxyXG5cclxuY29uc3QgVGFibGVDb21wb25lbnQ6IFJlYWN0LkZDPFByb3BzPiA9ICh7IGRhdGEgfSkgPT4ge1xyXG4gIHJldHVybiAoXHJcbiAgICA8dGFibGUgY2xhc3NOYW1lPVwiY2VudGVyZWQtdGFibGVcIj5cclxuICAgICAgPHRib2R5PlxyXG4gICAgICAgIHtkYXRhLm1hcCgocm93LCByb3dJbmRleCkgPT4gKFxyXG4gICAgICAgICAgPHRyIGtleT17cm93SW5kZXh9PlxyXG4gICAgICAgICAgICB7cm93Lm1hcCgoY2VsbCwgY2VsbEluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgICAgPHRkIGtleT17Y2VsbEluZGV4fT57Y2VsbH08L3RkPlxyXG4gICAgICAgICAgICApKX1cclxuICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgKSl9XHJcbiAgICAgIDwvdGJvZHk+XHJcbiAgICA8L3RhYmxlPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBUYWJsZUNvbXBvbmVudDtcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9rYXJhdi9PbmVEcml2ZS9Eb2N1bWVudHMvQ1MzMi9tb2NrLWJrYXJhdmFuLXlzdGVwYW5lL3NyYy9jb21wb25lbnRzL1RhYmxlQ29tcG9uZW50LnRzeCJ9