import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/REPLHistory.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=239115ef"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/karav/OneDrive/Documents/CS32/mock-bkaravan-ystepane/src/components/REPLHistory.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import "/src/styles/main.css";
import TableComponent from "/src/components/TableComponent.tsx";
export function REPLHistory(props) {
  return /* @__PURE__ */ jsxDEV("div", { className: "repl-history", children: props.commands.map((command, index) => /* @__PURE__ */ jsxDEV(TableComponent, { data: command }, void 0, false, {
    fileName: "C:/Users/karav/OneDrive/Documents/CS32/mock-bkaravan-ystepane/src/components/REPLHistory.tsx",
    lineNumber: 20,
    columnNumber: 47
  }, this)) }, void 0, false, {
    fileName: "C:/Users/karav/OneDrive/Documents/CS32/mock-bkaravan-ystepane/src/components/REPLHistory.tsx",
    lineNumber: 19,
    columnNumber: 10
  }, this);
}
_c = REPLHistory;
var _c;
$RefreshReg$(_c, "REPLHistory");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/karav/OneDrive/Documents/CS32/mock-bkaravan-ystepane/src/components/REPLHistory.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUJRO0FBckJSLDJCQUF5QjtBQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFaEMsT0FBTztBQUNQLE9BQU9BLG9CQUFvQjtBQWNwQixnQkFBU0MsWUFBWUMsT0FBeUI7QUFDbkQsU0FDRSx1QkFBQyxTQUFJLFdBQVUsZ0JBQ1pBLGdCQUFNQyxTQUFTQyxJQUFJLENBQUNDLFNBQVNDLFVBQzVCLHVCQUFDLGtCQUFlLE1BQU1ELFdBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBOEIsQ0FDL0IsS0FISDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBSUE7QUFFSjtBQUFDRSxLQVJlTjtBQUFXLElBQUFNO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJUYWJsZUNvbXBvbmVudCIsIlJFUExIaXN0b3J5IiwicHJvcHMiLCJjb21tYW5kcyIsIm1hcCIsImNvbW1hbmQiLCJpbmRleCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUkVQTEhpc3RvcnkudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IERpc3BhdGNoIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBSZWFjdCwgeyBDb21wb25lbnQgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IFwiLi4vc3R5bGVzL21haW4uY3NzXCI7XHJcbmltcG9ydCBUYWJsZUNvbXBvbmVudCBmcm9tIFwiLi9UYWJsZUNvbXBvbmVudFwiO1xyXG4vKipcclxuICogVGhpcyBpcyB0aGUgY29tcG9uZW50IHRoYXQgbWFuYWdlcyB0aGUgc2Nyb2xsYWJsZSBoaXN0b3J5IGJ5IGNyZWF0aW5nIGEgVGFibGVDb21wb25lbnQgb2YgYW4gSFRNTFRhYmxlLlxyXG4gKi9cclxuXHJcbi8qKlxyXG4gKiBUaGUgcHJvcHMgY29uc2lzdCBvZiBjb21tYW5kcyB3aGljaCBpcyBhIHN0cmluZ1tdW10gd2hlcmUgdGhlIGNvbW1hbmRzIGFyZSBwcm9jZXNzZWQuXHJcbiAqL1xyXG5pbnRlcmZhY2UgUkVQTEhpc3RvcnlQcm9wcyB7XHJcbiAgY29tbWFuZHM6IHN0cmluZ1tdW11bXTtcclxufVxyXG4vKipcclxuICogVGhpcyBmdW5jdGlvbiBjcmVhdGVzIHRoZSB0YWJsZSBhbmQgbWFwcyB0aGUgY29tbWFuZCB0byB0aGUgaW5kZXggYW5kIGJpbmQgdGhlIGRhdGEgdG8gaXQuXHJcbiAqL1xyXG5leHBvcnQgZnVuY3Rpb24gUkVQTEhpc3RvcnkocHJvcHM6IFJFUExIaXN0b3J5UHJvcHMpIHtcclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJyZXBsLWhpc3RvcnlcIj5cclxuICAgICAge3Byb3BzLmNvbW1hbmRzLm1hcCgoY29tbWFuZCwgaW5kZXgpID0+IChcclxuICAgICAgICA8VGFibGVDb21wb25lbnQgZGF0YT17Y29tbWFuZH0gLz5cclxuICAgICAgKSl9XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMva2FyYXYvT25lRHJpdmUvRG9jdW1lbnRzL0NTMzIvbW9jay1ia2FyYXZhbi15c3RlcGFuZS9zcmMvY29tcG9uZW50cy9SRVBMSGlzdG9yeS50c3gifQ==