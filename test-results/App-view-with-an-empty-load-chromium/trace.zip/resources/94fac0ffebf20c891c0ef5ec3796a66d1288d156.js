import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/REPL.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=239115ef"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/karav/OneDrive/Documents/CS32/mock-bkaravan-ystepane/src/components/REPL.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=239115ef"; const useState = __vite__cjsImport3_react["useState"];
import "/src/styles/main.css";
import { REPLHistory } from "/src/components/REPLHistory.tsx";
import { REPLInput } from "/src/components/REPLInput.tsx";
export default function REPL() {
  _s();
  const [history, setHistory] = useState([[[]]]);
  const [file, setFile] = useState([[]]);
  return /* @__PURE__ */ jsxDEV("div", { className: "repl", children: [
    /* @__PURE__ */ jsxDEV(REPLHistory, { commands: history }, void 0, false, {
      fileName: "C:/Users/karav/OneDrive/Documents/CS32/mock-bkaravan-ystepane/src/components/REPL.tsx",
      lineNumber: 15,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("hr", {}, void 0, false, {
      fileName: "C:/Users/karav/OneDrive/Documents/CS32/mock-bkaravan-ystepane/src/components/REPL.tsx",
      lineNumber: 16,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(REPLInput, { commands: history, file, setFile, setHistory }, void 0, false, {
      fileName: "C:/Users/karav/OneDrive/Documents/CS32/mock-bkaravan-ystepane/src/components/REPL.tsx",
      lineNumber: 17,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/karav/OneDrive/Documents/CS32/mock-bkaravan-ystepane/src/components/REPL.tsx",
    lineNumber: 14,
    columnNumber: 10
  }, this);
}
_s(REPL, "MjhuyBrGwpxERA4JzldDhi4VS1U=");
_c = REPL;
var _c;
$RefreshReg$(_c, "REPL");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/karav/OneDrive/Documents/CS32/mock-bkaravan-ystepane/src/components/REPL.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBY007Ozs7Ozs7Ozs7Ozs7Ozs7O0FBZE4sU0FBU0EsZ0JBQWdCO0FBQ3pCLE9BQU87QUFDUCxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsaUJBQWlCO0FBSzFCLHdCQUF3QkMsT0FBTztBQUFBQyxLQUFBO0FBQzdCLFFBQU0sQ0FBQ0MsU0FBU0MsVUFBVSxJQUFJTixTQUF1QixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDM0QsUUFBTSxDQUFDTyxNQUFNQyxPQUFPLElBQUlSLFNBQXFCLENBQUMsRUFBRSxDQUFDO0FBRWpELFNBQ0UsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSwyQkFBQyxlQUFZLFVBQVVLLFdBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBK0I7QUFBQSxJQUMvQix1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBSTtBQUFBLElBQ0osdUJBQUMsYUFDQyxVQUFVQSxTQUNWLE1BQ0EsU0FDQSxjQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJeUI7QUFBQSxPQVAzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBU0E7QUFFSjtBQUFDRCxHQWhCdUJELE1BQUk7QUFBQU0sS0FBSk47QUFBSSxJQUFBTTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJSRVBMSGlzdG9yeSIsIlJFUExJbnB1dCIsIlJFUEwiLCJfcyIsImhpc3RvcnkiLCJzZXRIaXN0b3J5IiwiZmlsZSIsInNldEZpbGUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlJFUEwudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBcIi4uL3N0eWxlcy9tYWluLmNzc1wiO1xyXG5pbXBvcnQgeyBSRVBMSGlzdG9yeSB9IGZyb20gXCIuL1JFUExIaXN0b3J5XCI7XHJcbmltcG9ydCB7IFJFUExJbnB1dCB9IGZyb20gXCIuL1JFUExJbnB1dFwiO1xyXG4vKipcclxuICogVGhpcyBpcyB0aGUgbWFpbiBSRVBMIGNsYXNzLiBJdCBiaW5kcyBoaXN0b3J5IGFuZCB0aGUgUkVQTElucHV0IHRvZ2V0aGVyLlxyXG4gKi9cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFJFUEwoKSB7XHJcbiAgY29uc3QgW2hpc3RvcnksIHNldEhpc3RvcnldID0gdXNlU3RhdGU8c3RyaW5nW11bXVtdPihbW1tdXV0pOyAvLyBoaXN0b3J5IHRoYXQgcmVjb3JkcyBldmVyeXRoaW5nIGFzIGEgdGFibGVcclxuICBjb25zdCBbZmlsZSwgc2V0RmlsZV0gPSB1c2VTdGF0ZTxzdHJpbmdbXVtdPihbW11dKTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwicmVwbFwiPlxyXG4gICAgICA8UkVQTEhpc3RvcnkgY29tbWFuZHM9e2hpc3Rvcnl9IC8+XHJcbiAgICAgIDxocj48L2hyPlxyXG4gICAgICA8UkVQTElucHV0XHJcbiAgICAgICAgY29tbWFuZHM9e2hpc3Rvcnl9XHJcbiAgICAgICAgZmlsZT17ZmlsZX1cclxuICAgICAgICBzZXRGaWxlPXtzZXRGaWxlfVxyXG4gICAgICAgIHNldEhpc3Rvcnk9e3NldEhpc3Rvcnl9XHJcbiAgICAgIC8+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMva2FyYXYvT25lRHJpdmUvRG9jdW1lbnRzL0NTMzIvbW9jay1ia2FyYXZhbi15c3RlcGFuZS9zcmMvY29tcG9uZW50cy9SRVBMLnRzeCJ9