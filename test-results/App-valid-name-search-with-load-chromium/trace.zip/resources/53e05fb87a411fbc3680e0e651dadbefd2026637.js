import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/REPLInput.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=239115ef"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/karav/OneDrive/Documents/CS32/mock-bkaravan-ystepane/src/components/REPLInput.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import "/src/styles/main.css";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=239115ef"; const useState = __vite__cjsImport4_react["useState"];
import { ControlledInput } from "/src/components/ControlledInput.tsx";
import { data, searchdata } from "/src/components/MockData.tsx";
export function REPLInput(props) {
  _s();
  const [commandString, setCommandString] = useState("");
  const [count, setCount] = useState(Number);
  const [mode, setMode] = useState(true);
  function handleSubmit(commandString2) {
    setCount(count + 1);
    let viewFlag = false;
    let searchRes = [[]];
    let splitInput = commandString2.split(" ");
    let output = "Output: ";
    switch (splitInput[0]) {
      case "mode": {
        setMode(!mode);
        output += handleMode(mode);
        break;
      }
      case "load_file": {
        if (splitInput.length != 2) {
          output += "Error: bad filepath!";
        } else {
          if (handleLoad(splitInput[1], props)) {
            output = output + "load_file of " + splitInput[1] + " successful!";
          } else {
            output = output + "Could not find " + splitInput[1];
          }
        }
        break;
      }
      case "view": {
        if (splitInput.length != 1) {
          output += "Error: view only takes in 1 argument. Take cs32 again!";
        } else {
          if (props.file[0].length !== 0) {
            viewFlag = true;
            output += "Successful view!";
          } else {
            output += "Error: no files were loaded.";
          }
        }
        break;
      }
      case "search": {
        if (splitInput.length !== 3) {
          output += "Error: search needs three args";
        } else {
          if (props.file[0].length !== 0) {
            searchRes = handleSearch(splitInput[1], splitInput[2]);
            output += "Searching! :)";
          } else {
            output += "Error: search requires a load";
          }
        }
        break;
      }
      default: {
        output = output + "Error: bad command. " + commandString2 + " is not a real command";
        break;
      }
    }
    handleOutput(props, mode, viewFlag, output, splitInput, searchRes);
    setCommandString("");
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "repl-input", children: [
    /* @__PURE__ */ jsxDEV("fieldset", { children: [
      /* @__PURE__ */ jsxDEV("legend", { children: "Enter a command:" }, void 0, false, {
        fileName: "C:/Users/karav/OneDrive/Documents/CS32/mock-bkaravan-ystepane/src/components/REPLInput.tsx",
        lineNumber: 88,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(ControlledInput, { value: commandString, setValue: setCommandString, ariaLabel: "Command input" }, void 0, false, {
        fileName: "C:/Users/karav/OneDrive/Documents/CS32/mock-bkaravan-ystepane/src/components/REPLInput.tsx",
        lineNumber: 89,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/karav/OneDrive/Documents/CS32/mock-bkaravan-ystepane/src/components/REPLInput.tsx",
      lineNumber: 87,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { onClick: () => handleSubmit(commandString), children: [
      "Submitted ",
      count,
      " times"
    ] }, void 0, true, {
      fileName: "C:/Users/karav/OneDrive/Documents/CS32/mock-bkaravan-ystepane/src/components/REPLInput.tsx",
      lineNumber: 91,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/karav/OneDrive/Documents/CS32/mock-bkaravan-ystepane/src/components/REPLInput.tsx",
    lineNumber: 86,
    columnNumber: 10
  }, this);
}
_s(REPLInput, "KlhRCIMZCdouxGRYE0oo7IKATvc=");
_c = REPLInput;
export function handleLoad(pathFile, props) {
  let file = data.get(pathFile);
  if (file !== void 0) {
    props.setFile(file);
    return true;
  }
  return false;
}
export function handleMode(state) {
  let output = "Mode switched to ";
  if (state) {
    output += "verbose";
  } else {
    output += "brief";
  }
  return output;
}
export function handleSearch(arg1, arg2) {
  let result = searchdata.get(arg1 + arg2);
  if (result !== void 0) {
    return result;
  }
  return [["Error: ", "search", "failed. ", " Keyword", "not ", "found."], ["Args", arg1, arg2]];
}
export function handleOutput(props, mode, viewFlag, output, command, searchRes) {
  let outputArray;
  let newCommand = ["Command: "].concat(command);
  outputArray = [newCommand];
  outputArray = outputArray.concat([output.split(" ")]);
  if (viewFlag) {
    outputArray = outputArray.concat(props.file);
  }
  outputArray = outputArray.concat(searchRes);
  if (mode) {
    props.setHistory([...props.commands, outputArray.slice(1)]);
  } else {
    props.setHistory([...props.commands, outputArray]);
  }
}
var _c;
$RefreshReg$(_c, "REPLInput");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/karav/OneDrive/Documents/CS32/mock-bkaravan-ystepane/src/components/REPLInput.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUZROzs7Ozs7Ozs7Ozs7Ozs7OztBQXpGUixPQUFPO0FBQ1AsU0FBbURBLGdCQUFnQjtBQUNuRSxTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0MsTUFBTUMsa0JBQWtCO0FBVzFCLGdCQUFTQyxVQUFVQyxPQUF1QjtBQUFBQyxLQUFBO0FBQy9DLFFBQU0sQ0FBQ0MsZUFBZUMsZ0JBQWdCLElBQUlSLFNBQWlCLEVBQUU7QUFDN0QsUUFBTSxDQUFDUyxPQUFPQyxRQUFRLElBQUlWLFNBQVNXLE1BQU07QUFDekMsUUFBTSxDQUFDQyxNQUFNQyxPQUFPLElBQUliLFNBQWtCLElBQUk7QUFFOUMsV0FBU2MsYUFBYVAsZ0JBQXVCO0FBQzNDRyxhQUFTRCxRQUFRLENBQUM7QUFDbEIsUUFBSU0sV0FBVztBQUNmLFFBQUlDLFlBQXdCLENBQUMsRUFBRTtBQUMvQixRQUFJQyxhQUFhVixlQUFjVyxNQUFNLEdBQUc7QUFDeEMsUUFBSUMsU0FBUztBQUViLFlBQVFGLFdBQVcsQ0FBQyxHQUFDO0FBQUEsTUFDbkIsS0FBSyxRQUFRO0FBQ1hKLGdCQUFRLENBQUNELElBQUk7QUFDYk8sa0JBQVVDLFdBQVdSLElBQUk7QUFDekI7QUFBQSxNQUNGO0FBQUEsTUFDQSxLQUFLLGFBQWE7QUFDaEIsWUFBSUssV0FBV0ksVUFBVSxHQUFHO0FBQzFCRixvQkFBVTtBQUFBLFFBQ1osT0FBTztBQUNMLGNBQUlHLFdBQVdMLFdBQVcsQ0FBQyxHQUFHWixLQUFLLEdBQUc7QUFDcENjLHFCQUFTQSxTQUFTLGtCQUFrQkYsV0FBVyxDQUFDLElBQUk7QUFBQSxVQUN0RCxPQUFPO0FBQ0xFLHFCQUFTQSxTQUFTLG9CQUFvQkYsV0FBVyxDQUFDO0FBQUEsVUFDcEQ7QUFBQSxRQUNGO0FBQ0E7QUFBQSxNQUNGO0FBQUEsTUFDQSxLQUFLLFFBQVE7QUFFWCxZQUFJQSxXQUFXSSxVQUFVLEdBQUc7QUFDMUJGLG9CQUFVO0FBQUEsUUFFWixPQUFPO0FBQ0wsY0FBSWQsTUFBTWtCLEtBQUssQ0FBQyxFQUFFRixXQUFXLEdBQUc7QUFFOUJOLHVCQUFXO0FBQ1hJLHNCQUFVO0FBQUEsVUFDWixPQUFPO0FBQ0xBLHNCQUFVO0FBQUEsVUFDWjtBQUFBLFFBQ0Y7QUFDQTtBQUFBLE1BQ0Y7QUFBQSxNQUNBLEtBQUssVUFBVTtBQUNiLFlBQUlGLFdBQVdJLFdBQVcsR0FBRztBQUMzQkYsb0JBQVU7QUFBQSxRQUNaLE9BQU87QUFDTCxjQUFJZCxNQUFNa0IsS0FBSyxDQUFDLEVBQUVGLFdBQVcsR0FBRztBQUM5Qkwsd0JBQVlRLGFBQWFQLFdBQVcsQ0FBQyxHQUFHQSxXQUFXLENBQUMsQ0FBQztBQUNyREUsc0JBQVU7QUFBQSxVQUNaLE9BQU87QUFDTEEsc0JBQVU7QUFBQSxVQUNaO0FBQUEsUUFDRjtBQUNBO0FBQUEsTUFDRjtBQUFBLE1BQ0EsU0FBUztBQUNQQSxpQkFDRUEsU0FDQSx5QkFDQVosaUJBQ0E7QUFDRjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQ0FrQixpQkFBYXBCLE9BQU9PLE1BQU1HLFVBQVVJLFFBQVFGLFlBQVlELFNBQVM7QUFDakVSLHFCQUFpQixFQUFFO0FBQUEsRUFDckI7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsMkJBQUMsY0FDQztBQUFBLDZCQUFDLFlBQU8sZ0NBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3QjtBQUFBLE1BQ3hCLHVCQUFDLG1CQUNDLE9BQU9ELGVBQ1AsVUFBVUMsa0JBQ1YsV0FBVyxtQkFIYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRzZCO0FBQUEsU0FML0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9BO0FBQUEsSUFDQSx1QkFBQyxZQUFPLFNBQVMsTUFBTU0sYUFBYVAsYUFBYSxHQUFHO0FBQUE7QUFBQSxNQUN2Q0U7QUFBQUEsTUFBTTtBQUFBLFNBRG5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLE9BWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVlBO0FBRUo7QUFBQ0gsR0F2RmVGLFdBQVM7QUFBQXNCLEtBQVR0QjtBQXlGVCxnQkFBU2tCLFdBQVdLLFVBQWtCdEIsT0FBZ0M7QUFDM0UsTUFBSWtCLE9BQU9yQixLQUFLMEIsSUFBSUQsUUFBUTtBQUM1QixNQUFJSixTQUFTTSxRQUFXO0FBQ3RCeEIsVUFBTXlCLFFBQVFQLElBQUk7QUFDbEIsV0FBTztBQUFBLEVBQ1Q7QUFDQSxTQUFPO0FBQ1Q7QUFFTyxnQkFBU0gsV0FBV1csT0FBd0I7QUFDakQsTUFBSVosU0FBUztBQUNiLE1BQUlZLE9BQU87QUFDVFosY0FBVTtBQUFBLEVBQ1osT0FBTztBQUNMQSxjQUFVO0FBQUEsRUFDWjtBQUNBLFNBQU9BO0FBQ1Q7QUFFTyxnQkFBU0ssYUFBYVEsTUFBY0MsTUFBMEI7QUFDbkUsTUFBSUMsU0FBUy9CLFdBQVd5QixJQUFJSSxPQUFPQyxJQUFJO0FBQ3ZDLE1BQUlDLFdBQVdMLFFBQVc7QUFDeEIsV0FBT0s7QUFBQUEsRUFDVDtBQUNBLFNBQU8sQ0FDTCxDQUFDLFdBQVcsVUFBVSxZQUFZLFlBQVksUUFBUSxRQUFRLEdBQzlELENBQUMsUUFBUUYsTUFBTUMsSUFBSSxDQUFDO0FBRXhCO0FBRU8sZ0JBQVNSLGFBQ2RwQixPQUNBTyxNQUNBRyxVQUNBSSxRQUNBZ0IsU0FDQW5CLFdBQ007QUFDTixNQUFJb0I7QUFDSixNQUFJQyxhQUFhLENBQUMsV0FBVyxFQUFFQyxPQUFPSCxPQUFPO0FBQzdDQyxnQkFBYyxDQUFDQyxVQUFVO0FBQ3pCRCxnQkFBY0EsWUFBWUUsT0FBTyxDQUFDbkIsT0FBT0QsTUFBTSxHQUFHLENBQUMsQ0FBQztBQUVwRCxNQUFJSCxVQUFVO0FBQ1pxQixrQkFBY0EsWUFBWUUsT0FBT2pDLE1BQU1rQixJQUFJO0FBQUEsRUFDN0M7QUFDQWEsZ0JBQWNBLFlBQVlFLE9BQU90QixTQUFTO0FBRTFDLE1BQUlKLE1BQU07QUFDUlAsVUFBTWtDLFdBQVcsQ0FBQyxHQUFHbEMsTUFBTW1DLFVBQVVKLFlBQVlLLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFBQSxFQUM1RCxPQUFPO0FBQ0xwQyxVQUFNa0MsV0FBVyxDQUFDLEdBQUdsQyxNQUFNbUMsVUFBVUosV0FBVyxDQUFDO0FBQUEsRUFDbkQ7QUFDRjtBQUFDLElBQUFWO0FBQUFnQixhQUFBaEIsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiQ29udHJvbGxlZElucHV0IiwiZGF0YSIsInNlYXJjaGRhdGEiLCJSRVBMSW5wdXQiLCJwcm9wcyIsIl9zIiwiY29tbWFuZFN0cmluZyIsInNldENvbW1hbmRTdHJpbmciLCJjb3VudCIsInNldENvdW50IiwiTnVtYmVyIiwibW9kZSIsInNldE1vZGUiLCJoYW5kbGVTdWJtaXQiLCJ2aWV3RmxhZyIsInNlYXJjaFJlcyIsInNwbGl0SW5wdXQiLCJzcGxpdCIsIm91dHB1dCIsImhhbmRsZU1vZGUiLCJsZW5ndGgiLCJoYW5kbGVMb2FkIiwiZmlsZSIsImhhbmRsZVNlYXJjaCIsImhhbmRsZU91dHB1dCIsIl9jIiwicGF0aEZpbGUiLCJnZXQiLCJ1bmRlZmluZWQiLCJzZXRGaWxlIiwic3RhdGUiLCJhcmcxIiwiYXJnMiIsInJlc3VsdCIsImNvbW1hbmQiLCJvdXRwdXRBcnJheSIsIm5ld0NvbW1hbmQiLCJjb25jYXQiLCJzZXRIaXN0b3J5IiwiY29tbWFuZHMiLCJzbGljZSIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlJFUExJbnB1dC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFwiLi4vc3R5bGVzL21haW4uY3NzXCI7XHJcbmltcG9ydCB7IERpc3BhdGNoLCBTZXRTdGF0ZUFjdGlvbiwgaXNWYWxpZEVsZW1lbnQsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IENvbnRyb2xsZWRJbnB1dCB9IGZyb20gXCIuL0NvbnRyb2xsZWRJbnB1dFwiO1xyXG5pbXBvcnQgeyBkYXRhLCBzZWFyY2hkYXRhIH0gZnJvbSBcIi4vTW9ja0RhdGFcIjtcclxuLyoqXHJcbiAqIFRoaXMgY29tcG9uZW50XHJcbiAqL1xyXG5leHBvcnQgaW50ZXJmYWNlIFJFUExJbnB1dFByb3BzIHtcclxuICBjb21tYW5kczogc3RyaW5nW11bXVtdO1xyXG4gIGZpbGU6IHN0cmluZ1tdW107XHJcbiAgc2V0RmlsZTogRGlzcGF0Y2g8U2V0U3RhdGVBY3Rpb248c3RyaW5nW11bXT4+O1xyXG4gIHNldEhpc3Rvcnk6IERpc3BhdGNoPFNldFN0YXRlQWN0aW9uPHN0cmluZ1tdW11bXT4+O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gUkVQTElucHV0KHByb3BzOiBSRVBMSW5wdXRQcm9wcykge1xyXG4gIGNvbnN0IFtjb21tYW5kU3RyaW5nLCBzZXRDb21tYW5kU3RyaW5nXSA9IHVzZVN0YXRlPHN0cmluZz4oXCJcIik7XHJcbiAgY29uc3QgW2NvdW50LCBzZXRDb3VudF0gPSB1c2VTdGF0ZShOdW1iZXIpO1xyXG4gIGNvbnN0IFttb2RlLCBzZXRNb2RlXSA9IHVzZVN0YXRlPGJvb2xlYW4+KHRydWUpO1xyXG5cclxuICBmdW5jdGlvbiBoYW5kbGVTdWJtaXQoY29tbWFuZFN0cmluZzogc3RyaW5nKSB7XHJcbiAgICBzZXRDb3VudChjb3VudCArIDEpO1xyXG4gICAgbGV0IHZpZXdGbGFnID0gZmFsc2U7XHJcbiAgICBsZXQgc2VhcmNoUmVzOiBzdHJpbmdbXVtdID0gW1tdXTtcclxuICAgIGxldCBzcGxpdElucHV0ID0gY29tbWFuZFN0cmluZy5zcGxpdChcIiBcIik7XHJcbiAgICBsZXQgb3V0cHV0ID0gXCJPdXRwdXQ6IFwiO1xyXG5cclxuICAgIHN3aXRjaCAoc3BsaXRJbnB1dFswXSkge1xyXG4gICAgICBjYXNlIFwibW9kZVwiOiB7XHJcbiAgICAgICAgc2V0TW9kZSghbW9kZSk7XHJcbiAgICAgICAgb3V0cHV0ICs9IGhhbmRsZU1vZGUobW9kZSk7XHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICAgIH1cclxuICAgICAgY2FzZSBcImxvYWRfZmlsZVwiOiB7XHJcbiAgICAgICAgaWYgKHNwbGl0SW5wdXQubGVuZ3RoICE9IDIpIHtcclxuICAgICAgICAgIG91dHB1dCArPSBcIkVycm9yOiBiYWQgZmlsZXBhdGghXCI7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIGlmIChoYW5kbGVMb2FkKHNwbGl0SW5wdXRbMV0sIHByb3BzKSkge1xyXG4gICAgICAgICAgICBvdXRwdXQgPSBvdXRwdXQgKyBcImxvYWRfZmlsZSBvZiBcIiArIHNwbGl0SW5wdXRbMV0gKyBcIiBzdWNjZXNzZnVsIVwiO1xyXG4gICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgb3V0cHV0ID0gb3V0cHV0ICsgXCJDb3VsZCBub3QgZmluZCBcIiArIHNwbGl0SW5wdXRbMV07XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGJyZWFrO1xyXG4gICAgICB9XHJcbiAgICAgIGNhc2UgXCJ2aWV3XCI6IHtcclxuICAgICAgICAvL2NhbGwgdmlld1xyXG4gICAgICAgIGlmIChzcGxpdElucHV0Lmxlbmd0aCAhPSAxKSB7XHJcbiAgICAgICAgICBvdXRwdXQgKz0gXCJFcnJvcjogdmlldyBvbmx5IHRha2VzIGluIDEgYXJndW1lbnQuIFRha2UgY3MzMiBhZ2FpbiFcIjtcclxuICAgICAgICAgIC8vIGJyZWFrO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBpZiAocHJvcHMuZmlsZVswXS5sZW5ndGggIT09IDApIHtcclxuICAgICAgICAgICAgLy8gY2hlY2sgaWYgd2UgbmVlZCB0aGUgaW5kZXhcclxuICAgICAgICAgICAgdmlld0ZsYWcgPSB0cnVlO1xyXG4gICAgICAgICAgICBvdXRwdXQgKz0gXCJTdWNjZXNzZnVsIHZpZXchXCI7XHJcbiAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBvdXRwdXQgKz0gXCJFcnJvcjogbm8gZmlsZXMgd2VyZSBsb2FkZWQuXCI7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGJyZWFrO1xyXG4gICAgICB9XHJcbiAgICAgIGNhc2UgXCJzZWFyY2hcIjoge1xyXG4gICAgICAgIGlmIChzcGxpdElucHV0Lmxlbmd0aCAhPT0gMykge1xyXG4gICAgICAgICAgb3V0cHV0ICs9IFwiRXJyb3I6IHNlYXJjaCBuZWVkcyB0aHJlZSBhcmdzXCI7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIGlmIChwcm9wcy5maWxlWzBdLmxlbmd0aCAhPT0gMCkge1xyXG4gICAgICAgICAgICBzZWFyY2hSZXMgPSBoYW5kbGVTZWFyY2goc3BsaXRJbnB1dFsxXSwgc3BsaXRJbnB1dFsyXSk7XHJcbiAgICAgICAgICAgIG91dHB1dCArPSBcIlNlYXJjaGluZyEgOilcIjtcclxuICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIG91dHB1dCArPSBcIkVycm9yOiBzZWFyY2ggcmVxdWlyZXMgYSBsb2FkXCI7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGJyZWFrO1xyXG4gICAgICB9XHJcbiAgICAgIGRlZmF1bHQ6IHtcclxuICAgICAgICBvdXRwdXQgPVxyXG4gICAgICAgICAgb3V0cHV0ICtcclxuICAgICAgICAgIFwiRXJyb3I6IGJhZCBjb21tYW5kLiBcIiArXHJcbiAgICAgICAgICBjb21tYW5kU3RyaW5nICtcclxuICAgICAgICAgIFwiIGlzIG5vdCBhIHJlYWwgY29tbWFuZFwiO1xyXG4gICAgICAgIGJyZWFrO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBoYW5kbGVPdXRwdXQocHJvcHMsIG1vZGUsIHZpZXdGbGFnLCBvdXRwdXQsIHNwbGl0SW5wdXQsIHNlYXJjaFJlcyk7XHJcbiAgICBzZXRDb21tYW5kU3RyaW5nKFwiXCIpO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwicmVwbC1pbnB1dFwiPlxyXG4gICAgICA8ZmllbGRzZXQ+XHJcbiAgICAgICAgPGxlZ2VuZD5FbnRlciBhIGNvbW1hbmQ6PC9sZWdlbmQ+XHJcbiAgICAgICAgPENvbnRyb2xsZWRJbnB1dFxyXG4gICAgICAgICAgdmFsdWU9e2NvbW1hbmRTdHJpbmd9XHJcbiAgICAgICAgICBzZXRWYWx1ZT17c2V0Q29tbWFuZFN0cmluZ31cclxuICAgICAgICAgIGFyaWFMYWJlbD17XCJDb21tYW5kIGlucHV0XCJ9XHJcbiAgICAgICAgLz5cclxuICAgICAgPC9maWVsZHNldD5cclxuICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVTdWJtaXQoY29tbWFuZFN0cmluZyl9PlxyXG4gICAgICAgIFN1Ym1pdHRlZCB7Y291bnR9IHRpbWVzXHJcbiAgICAgIDwvYnV0dG9uPlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGhhbmRsZUxvYWQocGF0aEZpbGU6IHN0cmluZywgcHJvcHM6IFJFUExJbnB1dFByb3BzKTogYm9vbGVhbiB7XHJcbiAgbGV0IGZpbGUgPSBkYXRhLmdldChwYXRoRmlsZSk7XHJcbiAgaWYgKGZpbGUgIT09IHVuZGVmaW5lZCkge1xyXG4gICAgcHJvcHMuc2V0RmlsZShmaWxlKTtcclxuICAgIHJldHVybiB0cnVlO1xyXG4gIH1cclxuICByZXR1cm4gZmFsc2U7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBoYW5kbGVNb2RlKHN0YXRlOiBib29sZWFuKTogc3RyaW5nIHtcclxuICBsZXQgb3V0cHV0ID0gXCJNb2RlIHN3aXRjaGVkIHRvIFwiO1xyXG4gIGlmIChzdGF0ZSkge1xyXG4gICAgb3V0cHV0ICs9IFwidmVyYm9zZVwiO1xyXG4gIH0gZWxzZSB7XHJcbiAgICBvdXRwdXQgKz0gXCJicmllZlwiO1xyXG4gIH1cclxuICByZXR1cm4gb3V0cHV0O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gaGFuZGxlU2VhcmNoKGFyZzE6IHN0cmluZywgYXJnMjogc3RyaW5nKTogc3RyaW5nW11bXSB7XHJcbiAgbGV0IHJlc3VsdCA9IHNlYXJjaGRhdGEuZ2V0KGFyZzEgKyBhcmcyKTtcclxuICBpZiAocmVzdWx0ICE9PSB1bmRlZmluZWQpIHtcclxuICAgIHJldHVybiByZXN1bHQ7XHJcbiAgfVxyXG4gIHJldHVybiBbXHJcbiAgICBbXCJFcnJvcjogXCIsIFwic2VhcmNoXCIsIFwiZmFpbGVkLiBcIiwgXCIgS2V5d29yZFwiLCBcIm5vdCBcIiwgXCJmb3VuZC5cIl0sXHJcbiAgICBbXCJBcmdzXCIsIGFyZzEsIGFyZzJdLFxyXG4gIF07XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBoYW5kbGVPdXRwdXQoXHJcbiAgcHJvcHM6IFJFUExJbnB1dFByb3BzLFxyXG4gIG1vZGU6IGJvb2xlYW4sXHJcbiAgdmlld0ZsYWc6IGJvb2xlYW4sXHJcbiAgb3V0cHV0OiBzdHJpbmcsXHJcbiAgY29tbWFuZDogc3RyaW5nW10sXHJcbiAgc2VhcmNoUmVzOiBzdHJpbmdbXVtdXHJcbik6IHZvaWQge1xyXG4gIGxldCBvdXRwdXRBcnJheTogc3RyaW5nW11bXTtcclxuICBsZXQgbmV3Q29tbWFuZCA9IFtcIkNvbW1hbmQ6IFwiXS5jb25jYXQoY29tbWFuZCk7XHJcbiAgb3V0cHV0QXJyYXkgPSBbbmV3Q29tbWFuZF07XHJcbiAgb3V0cHV0QXJyYXkgPSBvdXRwdXRBcnJheS5jb25jYXQoW291dHB1dC5zcGxpdChcIiBcIildKTtcclxuXHJcbiAgaWYgKHZpZXdGbGFnKSB7XHJcbiAgICBvdXRwdXRBcnJheSA9IG91dHB1dEFycmF5LmNvbmNhdChwcm9wcy5maWxlKTtcclxuICB9XHJcbiAgb3V0cHV0QXJyYXkgPSBvdXRwdXRBcnJheS5jb25jYXQoc2VhcmNoUmVzKTtcclxuXHJcbiAgaWYgKG1vZGUpIHtcclxuICAgIHByb3BzLnNldEhpc3RvcnkoWy4uLnByb3BzLmNvbW1hbmRzLCBvdXRwdXRBcnJheS5zbGljZSgxKV0pO1xyXG4gIH0gZWxzZSB7XHJcbiAgICBwcm9wcy5zZXRIaXN0b3J5KFsuLi5wcm9wcy5jb21tYW5kcywgb3V0cHV0QXJyYXldKTtcclxuICB9XHJcbn1cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9rYXJhdi9PbmVEcml2ZS9Eb2N1bWVudHMvQ1MzMi9tb2NrLWJrYXJhdmFuLXlzdGVwYW5lL3NyYy9jb21wb25lbnRzL1JFUExJbnB1dC50c3gifQ==