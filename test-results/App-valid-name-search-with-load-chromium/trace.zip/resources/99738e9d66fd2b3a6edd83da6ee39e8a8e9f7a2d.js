import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/styles/main.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "C:/Users/karav/OneDrive/Documents/CS32/mock-bkaravan-ystepane/src/styles/main.css"
const __vite__css = "/*\r\n  This is a reasonable starting point for the CSS in Mock.\r\n  Positioning in CSS can sometimes be annoying to manage, so we've opted to \r\n  give you this starter CSS. Feel free to modify it as you wish, though.\r\n*/\r\n\r\n.repl {\r\n  position: relative;\r\n  min-height: 95vh;\r\n}\r\n\r\n.repl-history {\r\n  height: 55vh;\r\n  margin: auto;\r\n  display: block;\r\n  overflow: scroll;\r\n}\r\n\r\n.repl-input {\r\n  margin: auto;\r\n  height: 10vh;\r\n}\r\n.repl-command-box {\r\n  width: 90%;\r\n  margin: auto;\r\n  display: block;\r\n}\r\nbutton {\r\n  margin: auto;\r\n  display: block;\r\n}\r\n"
__vite__updateStyle(__vite__id, __vite__css)
import.meta.hot.accept()
export default __vite__css
import.meta.hot.prune(() => __vite__removeStyle(__vite__id))